<!DOCTYPE HTML>
<html lang=pl>

<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="styl.css">
    <title>Restauracja</title>
</head>

<body>
    <header>
        <h1>Witamy w restauracji "Wszystkie smaki"</h1>
    </header>
    <div id="lewo">
        <img src="burger.jpg" alt="Nasze danie">
    </div>
    <div id="prawo">
        <h4>U nas dobrze zjesz!</h4>
        <ul>
            <li>Obiady od 40zł</li>
            <li>Przekąski od 10zł</li>
            <li>Kolacje od 20zł</li>
        </ul>
    </div>
    <div id="dol">
        <h2>Zarezerwuj stolik ON-LINE</h2>
        <form action="rezerwacja.php" method="POST">
            Data:<br />
            Format rrrr-mm-dd<br /><input type="data" name="Data" /><br />
            Ile osób:<br /><input type="number" value="osoby" /><br />
            Twój numer telefonu:<br /><input type="text" value="Numer" /><br />
            <input type='checkbox'>Zgadzam się na przetwarzanie moich danych osobowych<br>
            <input type='reset' name='wyczysc' value='Wyczyść'>
            <input type='submit' name='rezerwuj[]' value='rezerwuj'>
        </form>
    </div>
    <footer>
        Stronę internetową opracował: 000000000
   </footer>
</body>

</html>
