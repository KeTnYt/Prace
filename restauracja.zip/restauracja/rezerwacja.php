<?php
if (!empty ($_POST["Data"])&&!empty ($_POST["osoby"])&&!empty ($_POST["Numer"])){
$data = $_POST["Data"];
$liczbaosob = $_POST["osoby"];
$numer = $_POST["Numer"];
echo<<<END
<h2>Podsumowanie</h2>
<table border="1px solid black">
<tr>
    <td>Data</td> <td>Licza osób</td> <td>Numer</td>    
</tr> 
<tr>
   <td>$data</td> <td>$osoby</td> <td>$numer</td>    
</tr>
</table>
END;
}
else {
echo<<<END
<h2>Podsumowanie</h2>
<table border="1px solid black">
<tr>
    <td>Data</td> <td>Licza osób</td> <td>Numer</td>    
</tr> 
<tr>
   <td>123</td> <td>6432</td> <td>09876</td>    
</tr>
</table>
END;
}
?>